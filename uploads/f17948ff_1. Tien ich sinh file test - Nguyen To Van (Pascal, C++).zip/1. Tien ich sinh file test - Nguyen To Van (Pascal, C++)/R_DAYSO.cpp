#include <fstream>
#include <stdlib.h>
#include <time.h>

#define fi "DAYSO.INP"

const int MAXN=100;


using namespace std;

int random(int n) {
    return rand()%n;
}

int main()
{
    srand(time(NULL));

    fstream f;
    f.open(fi,ios::out);
    int n;
    n= 2 + random(MAXN - 2);
    f << n;
    f.close();
}


